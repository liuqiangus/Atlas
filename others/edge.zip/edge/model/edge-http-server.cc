/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2013 Magister Solutions
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Budiarto Herman <budiarto.herman@magister.fi>
 *
 */

#include "edge-http-server.h"
#include "edge-http-variables.h"

#include <ns3/log.h>
#include <ns3/simulator.h>
#include <ns3/callback.h>
#include <ns3/config.h>
#include <ns3/pointer.h>
#include <ns3/uinteger.h>
#include <ns3/packet.h>
#include <ns3/socket.h>
#include <ns3/tcp-socket.h>
#include <ns3/tcp-socket-factory.h>
#include <ns3/inet-socket-address.h>
#include <ns3/inet6-socket-address.h>
#include <numeric>

NS_LOG_COMPONENT_DEFINE ("EdgeHttpServer");


namespace ns3 {


// HTTP SERVER ////////////////////////////////////////////////////////////////


NS_OBJECT_ENSURE_REGISTERED (EdgeHttpServer);


EdgeHttpServer::EdgeHttpServer ()
  : m_state (NOT_STARTED),
  m_initialSocket (0),
  m_txBuffer (Create<EdgeHttpServerTxBuffer> ()),
  m_servQueue (Create<Service_Queue> ()),
  m_httpVariables (CreateObject<EdgeHttpVariables> ())
{
  NS_LOG_FUNCTION (this);

  m_mtuSize = m_httpVariables->GetMtuSize ();
  NS_LOG_INFO (this << " MTU size for this server application is "
                    << m_mtuSize << " bytes.");
}


// static
TypeId
EdgeHttpServer::GetTypeId ()
{
  static TypeId tid = TypeId ("ns3::EdgeHttpServer")
    .SetParent<Application> ()
    .AddConstructor<EdgeHttpServer> ()
    .AddAttribute ("Variables",
                   "Variable collection, which is used to control e.g. processing and "
                   "object generation delays.",
                   PointerValue (),
                   MakePointerAccessor (&EdgeHttpServer::m_httpVariables),
                   MakePointerChecker<EdgeHttpVariables> ())
    .AddAttribute ("LocalAddress",
                   "The local address of the server, "
                   "i.e., the address on which to bind the Rx socket.",
                   AddressValue (),
                   MakeAddressAccessor (&EdgeHttpServer::m_localAddress),
                   MakeAddressChecker ())
    .AddAttribute ("LocalPort",
                   "Port on which the application listen for incoming packets.",
                   UintegerValue (80), // the default HTTP port
                   MakeUintegerAccessor (&EdgeHttpServer::m_localPort),
                   MakeUintegerChecker<uint16_t> ())
    .AddAttribute ("Mtu",
                   "Maximum transmission unit (in bytes) of the TCP sockets "
                   "used in this application, excluding the compulsory 40 "
                   "bytes TCP header. Typical values are 1460 and 536 bytes. "
                   "The attribute is read-only because the value is randomly "
                   "determined.",
                   TypeId::ATTR_GET,
                   UintegerValue (),
                   MakeUintegerAccessor (&EdgeHttpServer::m_mtuSize),
                   MakeUintegerChecker<uint32_t> ())
    .AddTraceSource ("ConnectionEstablished",
                     "Connection to a remote web client has been established.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_connectionEstablishedTrace),
                     "ns3::HttpServer::ConnectionEstablishedCallback")
    .AddTraceSource ("MainObject",
                     "A main object has been generated.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_mainObjectTrace),
                     "ns3::HttpServer::HttpObjectCallback")
    .AddTraceSource ("Tx",
                     "A packet has been sent.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_txTrace),
                     "ns3::Packet::TracedCallback")
    .AddTraceSource ("Rx",
                     "A packet has been received.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_rxTrace),
                     "ns3::Packet::PacketAddressTracedCallback")
    .AddTraceSource ("RxDelay",
                     "A packet has been received with delay information.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_rxDelayTrace),
                     "ns3::Application::DelayAddressCallback")
    .AddTraceSource ("RxRtt",
                     "General trace of round trip delay time for receiving a complete object.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_rxRttTrace),
                     "ns3::Application::DelayAddressCallback")
    .AddTraceSource ("Queue",
                     "General trace of queue time of a task.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_queueTrace),
                     "ns3::Application::DelayAddressCallback")
    .AddTraceSource ("Compute",
                     "General trace of compute time of a task.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_computeTrace),
                     "ns3::Application::DelayAddressCallback")
    .AddTraceSource ("StateTransition",
                     "Trace fired upon every HTTP client state transition.",
                     MakeTraceSourceAccessor (&EdgeHttpServer::m_stateTransitionTrace),
                     "ns3::Application::StateTransitionCallback")
  ;
  return tid;
}


void
EdgeHttpServer::SetMtuSize (uint32_t mtuSize)
{
  NS_LOG_FUNCTION (this << mtuSize);
  m_mtuSize = mtuSize;
}


Ptr<Socket>
EdgeHttpServer::GetSocket () const
{
  return m_initialSocket;
}


EdgeHttpServer::State_t
EdgeHttpServer::GetState () const
{
  return m_state;
}


std::string
EdgeHttpServer::GetStateString () const
{
  return GetStateString (m_state);
}


// static
std::string
EdgeHttpServer::GetStateString (EdgeHttpServer::State_t state)
{
  switch (state)
    {
    case NOT_STARTED:
      return "NOT_STARTED";
      break;
    case STARTED:
      return "STARTED";
      break;
    case STOPPED:
      return "STOPPED";
      break;
    default:
      NS_FATAL_ERROR ("Unknown state");
      return "FATAL_ERROR";
      break;
    }
}


void
EdgeHttpServer::DoDispose ()
{
  NS_LOG_FUNCTION (this);

  if (!Simulator::IsFinished ())
    {
      StopApplication ();
    }

  Application::DoDispose (); // Chain up.
}


void
EdgeHttpServer::StartApplication ()
{
  NS_LOG_FUNCTION (this);

  if (m_state == NOT_STARTED)
    {
      m_httpVariables->Initialize ();
      if (m_initialSocket == 0)
        {
          // Find the current default MTU value of TCP sockets.
          Ptr<const ns3::AttributeValue> previousSocketMtu;
          const TypeId tcpSocketTid = TcpSocket::GetTypeId ();
          for (uint32_t i = 0; i < tcpSocketTid.GetAttributeN (); i++)
            {
              struct TypeId::AttributeInformation attrInfo = tcpSocketTid.GetAttribute (i);
              if (attrInfo.name == "SegmentSize")
                {
                  previousSocketMtu = attrInfo.initialValue;
                }
            }

          // Creating a TCP socket to connect to the server.
          m_initialSocket = Socket::CreateSocket (GetNode (),
                                                  TcpSocketFactory::GetTypeId ());
          m_initialSocket->SetAttribute ("SegmentSize", UintegerValue (m_mtuSize));

          [[maybe_unused]] int ret;

          if (Ipv4Address::IsMatchingType (m_localAddress))
            {
              const Ipv4Address ipv4 = Ipv4Address::ConvertFrom (m_localAddress);
              const InetSocketAddress inetSocket = InetSocketAddress (ipv4,
                                                                      m_localPort);
              NS_LOG_INFO (this << " Binding on " << ipv4
                                << " port " << m_localPort
                                << " / " << inetSocket << ".");
              ret = m_initialSocket->Bind (inetSocket);
              NS_LOG_DEBUG (this << " Bind() return value= " << ret
                                 << " GetErrNo= "
                                 << m_initialSocket->GetErrno () << ".");
            }
          else if (Ipv6Address::IsMatchingType (m_localAddress))
            {
              const Ipv6Address ipv6 = Ipv6Address::ConvertFrom (m_localAddress);
              const Inet6SocketAddress inet6Socket = Inet6SocketAddress (ipv6,
                                                                         m_localPort);
              NS_LOG_INFO (this << " Binding on " << ipv6
                                << " port " << m_localPort
                                << " / " << inet6Socket << ".");
              ret = m_initialSocket->Bind (inet6Socket);
              NS_LOG_DEBUG (this << " Bind() return value= " << ret
                                 << " GetErrNo= "
                                 << m_initialSocket->GetErrno () << ".");
            }

          ret = m_initialSocket->Listen ();
          NS_LOG_DEBUG (this << " Listen () return value= " << ret
                             << " GetErrNo= " << m_initialSocket->GetErrno ()
                             << ".");


        } // end of `if (m_initialSocket == 0)`

      NS_ASSERT_MSG (m_initialSocket != 0, "Failed creating socket.");
      m_initialSocket->SetAcceptCallback (MakeCallback (&EdgeHttpServer::ConnectionRequestCallback,
                                                        this),
                                          MakeCallback (&EdgeHttpServer::NewConnectionCreatedCallback,
                                                        this));
      m_initialSocket->SetCloseCallbacks (MakeCallback (&EdgeHttpServer::NormalCloseCallback,
                                                        this),
                                          MakeCallback (&EdgeHttpServer::ErrorCloseCallback,
                                                        this));
      m_initialSocket->SetRecvCallback (MakeCallback (&EdgeHttpServer::ReceivedDataCallback,
                                                      this));
      m_initialSocket->SetSendCallback (MakeCallback (&EdgeHttpServer::SendCallback,
                                                      this));
      SwitchToState (STARTED);

    } // end of `if (m_state == NOT_STARTED)`
  else
    {
      NS_FATAL_ERROR ("Invalid state " << GetStateString ()
                                       << " for StartApplication().");
    }

} // end of `void StartApplication ()`


void
EdgeHttpServer::StopApplication ()
{
  NS_LOG_FUNCTION (this);

  SwitchToState (STOPPED);

  // Close all accepted sockets.
  m_txBuffer->CloseAllSockets ();

  // Stop listening.
  if (m_initialSocket != 0)
    {
      m_initialSocket->Close ();
      m_initialSocket->SetAcceptCallback (MakeNullCallback<bool, Ptr<Socket>, const Address &> (),
                                          MakeNullCallback<void, Ptr<Socket>, const Address &> ());
      m_initialSocket->SetCloseCallbacks (MakeNullCallback<void, Ptr<Socket> > (),
                                          MakeNullCallback<void, Ptr<Socket> > ());
      m_initialSocket->SetRecvCallback (MakeNullCallback<void, Ptr<Socket> > ());
      m_initialSocket->SetSendCallback (MakeNullCallback<void, Ptr<Socket>, uint32_t > ());
    }
}


bool
EdgeHttpServer::ConnectionRequestCallback (Ptr<Socket> socket,
                                               const Address &address)
{
  NS_LOG_FUNCTION (this << socket << address);
  return true; // Unconditionally accept the connection request.
}


void
EdgeHttpServer::NewConnectionCreatedCallback (Ptr<Socket> socket,
                                                  const Address &address)
{
  NS_LOG_FUNCTION (this << socket << address);

  socket->SetCloseCallbacks (MakeCallback (&EdgeHttpServer::NormalCloseCallback,
                                           this),
                             MakeCallback (&EdgeHttpServer::ErrorCloseCallback,
                                           this));
  socket->SetRecvCallback (MakeCallback (&EdgeHttpServer::ReceivedDataCallback,
                                         this));
  socket->SetSendCallback (MakeCallback (&EdgeHttpServer::SendCallback,
                                         this));

  m_connectionEstablishedTrace (this, socket);
  m_txBuffer->AddSocket (socket);

  /*
   * A typical connection is established after receiving an empty (i.e., no
   * data) TCP packet with ACK flag. The actual data will follow in a separate
   * packet after that and will be received by ReceivedDataCallback().
   *
   * However, that empty ACK packet might get lost. In this case, we may
   * receive the first data packet right here already, because it also counts
   * as a new connection. The statement below attempts to fetch the data from
   * that packet, if any.
   */
  ReceivedDataCallback (socket);
}


void
EdgeHttpServer::NormalCloseCallback (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);

  if (socket == m_initialSocket)
    {
      if (m_state == STARTED)
        {
          NS_FATAL_ERROR ("Initial listener socket shall not be closed"
                          << " when the server instance is still running.");
        }
    }
  else if (m_txBuffer->IsSocketAvailable (socket))
    {
      // The application should now prepare to close the socket.
      if (m_txBuffer->IsBufferEmpty (socket))
        {
          /*
           * Here we declare that we have nothing more to send and the socket
           * may be closed immediately.
           */
          socket->ShutdownSend ();
          m_txBuffer->RemoveSocket (socket);
        }
      else
        {
          /*
           * Remember to close the socket later, whenever the buffer becomes
           * empty.
           */
          m_txBuffer->PrepareClose (socket);
        }
    }
}


void
EdgeHttpServer::ErrorCloseCallback (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);

  if (socket == m_initialSocket)
    {
      if (m_state == STARTED)
        {
          NS_FATAL_ERROR ("Initial listener socket shall not be closed"
                          << " when the server instance is still running.");
        }
    }
  else if (m_txBuffer->IsSocketAvailable (socket))
    {
      m_txBuffer->CloseSocket (socket);
    }
}

void
EdgeHttpServer::Receive (Ptr<Packet> packet, Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << packet);

  /* In a "real" HTTP message the message size is coded differently. The use of a header
   * is to avoid the burden of doing a real message parser.
   */
  bool firstPacket = false;

  if (m_txBuffer->GetobjectBytesToBeReceived(socket) == 0)
    {
      // This is the first packet of the object.
      firstPacket = true;

      // Remove the header in order to calculate remaining data to be received.
      EdgeHttpHeader httpHeader;
      packet->RemoveHeader (httpHeader);

      m_txBuffer->SetobjectBytesToBeReceived(socket, httpHeader.GetContentLength ());
      m_txBuffer->SetobjectClientTs(socket, httpHeader.GetClientTs ());
      m_txBuffer->SetobjectServerTs(socket, httpHeader.GetServerTs ());

      // Take a copy for constructed packet trace. Note that header is included.
      m_txBuffer->SetconstructedPacket(socket, packet->Copy ());
      Ptr<Packet> m_constructedPacket = m_txBuffer->GetconstructedPacket(socket);
      m_constructedPacket->AddHeader (httpHeader); // change it 
    }
  uint32_t contentSize = packet->GetSize ();

  /* Note that the packet does not contain header at this point.
   * The content is purely raw data, which was the only intended data to be received.
   */
  if (m_txBuffer->GetobjectBytesToBeReceived(socket) < contentSize)
    {
      NS_LOG_WARN (this << " The received packet"
                        << " (" << contentSize << " bytes of content)"
                        << " is larger than"
                        << " the content that we expected to receive"
                        << " (" << m_txBuffer->GetobjectBytesToBeReceived(socket) << " bytes).");
      // Stop expecting any more packet of this object.
      m_txBuffer->SetobjectBytesToBeReceived(socket, 0);
      m_txBuffer->SetconstructedPacket(socket, NULL);
    }
  else
    {
      m_txBuffer->SetobjectBytesToBeReceived(socket, m_txBuffer->GetobjectBytesToBeReceived(socket) - contentSize);

      if (!firstPacket)
        {
          Ptr<Packet> packetCopy = packet->Copy ();
          Ptr<Packet> m_constructedPacket = m_txBuffer->GetconstructedPacket(socket);
          m_constructedPacket->AddAtEnd (packetCopy);
        }
    }

} // end of `void Receive (packet)`


void
EdgeHttpServer::ReceiveMainObject (Ptr<Packet> packet, const Address &from, Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << packet << from);

  if (true)
    {
      /*
       * In the following call to Receive(), #m_objectBytesToBeReceived *will*
       * be updated. #m_objectClientTs and #m_objectServerTs *may* be updated.
       * EdgeHttpHeader will be removed from the packet, if it is the first
       * packet of the object to be received; the header will be available in
       * #m_constructedPacketHeader.
       * #m_constructedPacket will also be updated.
       */
      // EdgeHttpHeader httpHeader;
      // packet->PeekHeader (httpHeader);

      // std::map<Ptr<Socket>, TxBuffer_t>::const_iterator it;
      // it = m_txBuffer.find (socket);
      m_txBuffer->IsSocketAvailable(socket);
      Receive (packet, socket);
      // m_rxMainObjectPacketTrace (packet);

      if (m_txBuffer->GetobjectBytesToBeReceived(socket) > 0)
        {
          /*
           * There are more packets of this main object, so just stay still
           * and wait until they arrive.
           */
          NS_LOG_INFO (this << " " << m_txBuffer->GetobjectBytesToBeReceived(socket) << " byte(s)"
                            << " remains from this chunk of main object.");
        }
      else
        {
          /*
           * This is the last packet of this main object. Acknowledge the
           * reception of a whole main object
           */
          NS_LOG_INFO (this << " Finished receiving a main object.");
          // m_rxMainObjectTrace (this, m_txBuffer->GetconstructedPacket(socket));
          Time m_objectServerTs = m_txBuffer->GetobjectServerTs(socket);
          Time m_objectClientTs = m_txBuffer->GetobjectClientTs(socket);

          if (!m_objectServerTs.IsZero ())
            {
              m_rxDelayTrace (Simulator::Now () - m_objectServerTs, from);
              m_objectServerTs = MilliSeconds (0); // Reset back to zero.
            }

          if (!m_objectClientTs.IsZero ())
            {
              m_rxRttTrace (Simulator::Now () - m_objectClientTs, from);
              m_objectClientTs = MilliSeconds (0); // Reset back to zero.
            }

          EnterComputationTime (socket, from);

        } // end of else of `if (m_objectBytesToBeReceived > 0)`

    } // end of `if (m_state == EXPECTING_MAIN_OBJECT)`
  else
    {
      NS_FATAL_ERROR ("Invalid state " << GetStateString ()
                                       << " for ReceiveMainObject().");
    }

} // end of `void ReceiveMainObject (Ptr<Packet> packet)`


void
EdgeHttpServer::EnterComputationTime (Ptr<Socket> socket, const Address &from)
{
  NS_LOG_FUNCTION (this << from);

  const Time computationTime = m_httpVariables->GetComputeTime ();
  NS_LOG_INFO (this << " Client will need "
                    << computationTime.As (Time::MS) << " to be finished in the edge server.");

  m_servQueue->Enqueue_task(computationTime, Simulator::Now());
  Time current_queue_time = m_servQueue->GetQueueTime();

  NS_LOG_INFO (this << " Client will be queued for "
                    << current_queue_time.As (Time::MS) 
                    << " and computed for" 
                    << computationTime.As (Time::MS) 
                    << " with queue size "
                    <<m_servQueue->GetQueueSize()<<".");

  m_queueTrace (current_queue_time, m_servQueue->GetQueueSize(), from); // record the queue time
  m_computeTrace(computationTime, from); // record the compute time
  m_txBuffer->RecordNextServe ( socket, 
                                Simulator::Schedule ( current_queue_time + computationTime, 
                                                      &EdgeHttpServer::ServeNewMainObject,
                                                      this, socket),
                                m_txBuffer->GetClientTs(socket));

}

void
EdgeHttpServer::ReceivedDataCallback (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);

  Ptr<Packet> packet;
  Address from;

  while ((packet = socket->RecvFrom (from)))
    {
      if (packet->GetSize () == 0)
        {
          break; // EOF
        }

#ifdef NS3_LOG_ENABLE
      // Some log messages.
      if (InetSocketAddress::IsMatchingType (from))
        {
          NS_LOG_INFO (this << " A packet of " << packet->GetSize () << " bytes"
                            << " received from " << InetSocketAddress::ConvertFrom (from).GetIpv4 ()
                            << " port " << InetSocketAddress::ConvertFrom (from).GetPort ()
                            << " / " << InetSocketAddress::ConvertFrom (from));
        }
      else if (Inet6SocketAddress::IsMatchingType (from))
        {
          NS_LOG_INFO (this << " A packet of " << packet->GetSize () << " bytes"
                            << " received from " << Inet6SocketAddress::ConvertFrom (from).GetIpv6 ()
                            << " port " << Inet6SocketAddress::ConvertFrom (from).GetPort ()
                            << " / " << Inet6SocketAddress::ConvertFrom (from));
        }
#endif /* NS3_LOG_ENABLE */

      // Check the header. No need to remove it, since it is not a "real" header.
      // EdgeHttpHeader httpHeader;
      // packet->PeekHeader (httpHeader);

      // Fire trace sources.
      m_rxTrace (packet, from);
      m_rxDelayTrace (Simulator::Now () - m_txBuffer->GetobjectClientTs(socket), from);

      ReceiveMainObject (packet, from, socket);

    } // end of `while ((packet = socket->RecvFrom (from)))`

} // end of `void ReceivedDataCallback (Ptr<Socket> socket)`


void
EdgeHttpServer::SendCallback (Ptr<Socket> socket, uint32_t availableBufferSize)
{
  NS_LOG_FUNCTION (this << socket << availableBufferSize);

  if (!m_txBuffer->IsBufferEmpty (socket))
    {
      [[maybe_unused]] const uint32_t txBufferSize = m_txBuffer->GetBufferSize (socket);
      [[maybe_unused]] const uint32_t actualSent = ServeFromTxBuffer (socket);

#ifdef NS3_LOG_ENABLE
      // Some log messages.
      if (actualSent < txBufferSize)
        {
          switch (m_txBuffer->GetBufferContentType (socket))
            {
            case EdgeHttpHeader::MAIN_OBJECT:
              NS_LOG_INFO (this << " Transmission of main object is suspended"
                                << " after " << actualSent << " bytes.");
              break;
    
            default:
              NS_FATAL_ERROR ("Invalid Tx buffer content type.");
              break;
            }
        }
      else
        {
          switch (m_txBuffer->GetBufferContentType (socket))
            {
            case EdgeHttpHeader::MAIN_OBJECT:
              NS_LOG_INFO (this << " Finished sending a whole main object.");
              break;
          
            default:
              NS_FATAL_ERROR ("Invalid Tx buffer content type.");
              break;
            }
        }
#endif /* NS3_LOG_ENABLE */

    } // end of `if (m_txBuffer->IsBufferEmpty (socket))`

} // end of `void SendCallback (Ptr<Socket> socket, uint32_t availableBufferSize)`


void
EdgeHttpServer::ServeNewMainObject (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);

  //////////////////////////////////////////////////////////////////

  m_servQueue->Dequeue_task(); // dequeue the front task as the server starts to send DL packet out

  //////////////////////////////////////////////////////////////////

  const uint32_t objectSize = m_httpVariables->GetMainObjectSize ();
  NS_LOG_INFO (this << " Main object to be served is "
                    << objectSize << " bytes.");
  m_mainObjectTrace (objectSize);
  m_txBuffer->WriteNewObject (socket, EdgeHttpHeader::MAIN_OBJECT,
                              objectSize);
  const uint32_t actualSent = ServeFromTxBuffer (socket);

  if (actualSent < objectSize)
    {
      NS_LOG_INFO (this << " Transmission of main object is suspended"
                        << " after " << actualSent << " bytes.");
    }
  else
    {
      NS_LOG_INFO (this << " Finished sending a whole main object.");
    }
}



uint32_t
EdgeHttpServer::ServeFromTxBuffer (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);

  if (m_txBuffer->IsBufferEmpty (socket))
    {
      NS_LOG_LOGIC (this << " Tx buffer is empty. Not sending anything.");
      return 0;
    }
  bool firstPartOfObject = !m_txBuffer->HasTxedPartOfObject (socket);

  const uint32_t socketSize = socket->GetTxAvailable ();
  NS_LOG_DEBUG (this << " Socket has " << socketSize
                     << " bytes available for Tx.");

  // Get the number of bytes remaining to be sent.
  const uint32_t txBufferSize = m_txBuffer->GetBufferSize (socket);

  // Compute the size of actual content to be sent; has to fit into the socket.
  // Note that header size is NOT counted as TxBuffer content. Header size is overhead.
  uint32_t contentSize = std::min (txBufferSize, socketSize  - 22);
  Ptr<Packet> packet = Create<Packet> (contentSize);
  uint32_t packetSize = contentSize;
  if (packetSize == 0)
    {
      NS_LOG_LOGIC (this << " Socket size leads to packet size of zero; not sending anything.");
      return 0;
    }

  // If this is the first packet of an object, attach a header.
  if (firstPartOfObject)
    {
      // Create header.
      EdgeHttpHeader httpHeader;
      httpHeader.SetContentLength (txBufferSize);
      httpHeader.SetContentType (m_txBuffer->GetBufferContentType (socket));
      // Using the client TS value as per the corresponding request packet.
      httpHeader.SetClientTs (m_txBuffer->GetobjectClientTs (socket));
      httpHeader.SetServerTs (Simulator::Now ());
      packet->AddHeader (httpHeader);
      packetSize += httpHeader.GetSerializedSize ();

      NS_LOG_INFO (this << " Created packet " << packet << " of "
                        << packetSize << " bytes."
                        << " The corresponding request came "
                        << (Simulator::Now () - httpHeader.GetClientTs ()).As (Time::S)
                        << " ago.");
    }
  else
    {
      NS_LOG_INFO (this << " Created packet " << packet << " of "
                        << packetSize << " bytes to be appended to a previous packet.");
    }

  // Send.
  const int actualBytes = socket->Send (packet);
  NS_LOG_DEBUG (this << " Send() packet " << packet
                     << " of " << packetSize << " bytes,"
                     << " return value= " << actualBytes << ".");
  m_txTrace (packet);

  if (actualBytes == static_cast<int> (packetSize))
    {
      // The packet goes through successfully.
      m_txBuffer->DepleteBufferSize (socket, contentSize);
      NS_LOG_INFO (this << " Remaining object to be sent "
                        << m_txBuffer->GetBufferSize (socket) << " bytes.");
      return packetSize;
    }
  else
    {
      NS_LOG_INFO (this << " Failed to send object,"
                        << " GetErrNo= " << socket->GetErrno () << ","
                        << " suspending transmission"
                        << " and waiting for another Tx opportunity.");
      return 0;
    }

} // end of `uint32_t ServeFromTxBuffer (Ptr<Socket> socket)`


void
EdgeHttpServer::SwitchToState (EdgeHttpServer::State_t state)
{
  const std::string oldState = GetStateString ();
  const std::string newState = GetStateString (state);
  NS_LOG_FUNCTION (this << oldState << newState);
  m_state = state;
  NS_LOG_INFO (this << " EdgeHttpServer " << oldState
                    << " --> " << newState << ".");
  m_stateTransitionTrace (oldState, newState);
}

/// Service Queue ////////////////////////////////////////////////////////////

Service_Queue::Service_Queue ()
{
  NS_LOG_FUNCTION (this);
}

uint16_t
Service_Queue::GetQueueSize(void)
{
  // make sure all queues are in the same page
  NS_ASSERT(m_time.size() == m_comp.size());
  return m_time.size();
}

Time
Service_Queue::GetQueueTime(void)
{ 
  Time curr_queuing_time = MilliSeconds(0);

  if (GetQueueSize()>0)
  {
    // cumulative comp time for all tasks in the queue
    Time cum_comp_time = MilliSeconds(0); // add them manually to assure the same "Time" type
    for (auto it = m_comp.begin();it != m_comp.end(); ++it)
        cum_comp_time += *it;

    Time front_queue_time = MilliSeconds(0); // the first time, the m_queue is not enqueued, so this can be none item 
    if (m_queue.size()>0) front_queue_time = m_queue.front();

    // the actual executed compute time of the front task, as it may be queued for a while then start to execute
    Time front_executed_time = m_time.back() - (m_time.front() + front_queue_time); // the last () part is the actual start time of the computate of the front task
    
    curr_queuing_time = cum_comp_time - front_executed_time - m_comp.back(); // here, minus the current comp time, which is added in cum_comp_time

    if (curr_queuing_time<=MilliSeconds(0)) {curr_queuing_time = MilliSeconds(0);}
    
  }
  else{}

  return curr_queuing_time;
}


void
Service_Queue::Enqueue_task (Time comp_time, Time curr_sim_time)
{ 
  m_comp.push_back(comp_time);
  m_time.push_back(curr_sim_time);
  Time queue_time = GetQueueTime(); // has to be before queue time push
  m_queue.push_back(queue_time);

  // if (m_queue.size()>10000) ; // some warning as the queues size increases too high
}

void
Service_Queue::Dequeue_task (void)
{
  if (!m_queue.empty())
  {
    m_queue.erase(m_queue.begin());
    m_time.erase(m_time.begin());
    m_comp.erase(m_comp.begin());
  }
  else
  {
    // no item in queue, this should have a warning here.
  }
}



// HTTP SERVER TX BUFFER //////////////////////////////////////////////////////


EdgeHttpServerTxBuffer::EdgeHttpServerTxBuffer ()
{
  NS_LOG_FUNCTION (this);
}

bool
EdgeHttpServerTxBuffer::IsSocketAvailable (Ptr<Socket> socket) const
{
  std::map<Ptr<Socket>, TxBuffer_t>::const_iterator it;
  it = m_txBuffer.find (socket);
  return (it != m_txBuffer.end ());
}

void
EdgeHttpServerTxBuffer::AddSocket (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);

  NS_ASSERT_MSG (!IsSocketAvailable (socket),
                 this << " Cannot add socket " << socket
                      << " because it has already been added before.");

  TxBuffer_t txBuffer;
  txBuffer.txBufferContentType = EdgeHttpHeader::NOT_SET;
  txBuffer.txBufferSize = 0;
  txBuffer.isClosing = false;
  txBuffer.hasTxedPartOfObject = false;
  txBuffer.m_objectBytesToBeReceived = 0;
  txBuffer.m_constructedPacket =NULL;
  txBuffer.m_objectClientTs = MilliSeconds(0);
  txBuffer.m_objectServerTs = MilliSeconds(0);
  m_txBuffer.insert (std::pair<Ptr<Socket>, TxBuffer_t> (socket, txBuffer));
}


void
EdgeHttpServerTxBuffer::RemoveSocket (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);

  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");

  if (!Simulator::IsExpired (it->second.nextServe))
    {
      NS_LOG_INFO (this << " Canceling a serving event which is due in "
                        << Simulator::GetDelayLeft (it->second.nextServe).As (Time::S)
                        << ".");
      Simulator::Cancel (it->second.nextServe);
    }

  it->first->SetCloseCallbacks (MakeNullCallback<void, Ptr<Socket> > (),
                                MakeNullCallback<void, Ptr<Socket> > ());
  it->first->SetRecvCallback (MakeNullCallback<void, Ptr<Socket> > ());
  it->first->SetSendCallback (MakeNullCallback<void, Ptr<Socket>, uint32_t > ());

  m_txBuffer.erase (it);
}


void
EdgeHttpServerTxBuffer::CloseSocket (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);

  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");

  if (!Simulator::IsExpired (it->second.nextServe))
    {
      NS_LOG_INFO (this << " Canceling a serving event which is due in "
                        << Simulator::GetDelayLeft (it->second.nextServe).As (Time::S)
                        << ".");
      Simulator::Cancel (it->second.nextServe);
    }

  if (it->second.txBufferSize > 0)
    {
      NS_LOG_WARN (this << " Closing a socket where "
                        << it->second.txBufferSize << " bytes of transmission"
                        << " is still pending in the corresponding Tx buffer.");
    }

  it->first->Close ();
  it->first->SetCloseCallbacks (MakeNullCallback<void, Ptr<Socket> > (),
                                MakeNullCallback<void, Ptr<Socket> > ());
  it->first->SetRecvCallback (MakeNullCallback<void, Ptr<Socket> > ());
  it->first->SetSendCallback (MakeNullCallback<void, Ptr<Socket>, uint32_t > ());

  m_txBuffer.erase (it);
}


void
EdgeHttpServerTxBuffer::CloseAllSockets ()
{
  NS_LOG_FUNCTION (this);

  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  for (it = m_txBuffer.begin (); it != m_txBuffer.end (); ++it)
    {
      if (!Simulator::IsExpired (it->second.nextServe))
        {
          NS_LOG_INFO (this << " Canceling a serving event which is due in "
                            << Simulator::GetDelayLeft (it->second.nextServe).As (Time::S)
                            << ".");
          Simulator::Cancel (it->second.nextServe);
        }

      it->first->Close ();
      it->first->SetCloseCallbacks (MakeNullCallback<void, Ptr<Socket> > (),
                                    MakeNullCallback<void, Ptr<Socket> > ());
      it->first->SetRecvCallback (MakeNullCallback<void, Ptr<Socket> > ());
      it->first->SetSendCallback (MakeNullCallback<void, Ptr<Socket>, uint32_t > ());
    }

  m_txBuffer.clear ();
}


bool
EdgeHttpServerTxBuffer::IsBufferEmpty (Ptr<Socket> socket) const
{
  std::map<Ptr<Socket>, TxBuffer_t>::const_iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  return (it->second.txBufferSize == 0);
}


Time
EdgeHttpServerTxBuffer::GetClientTs (Ptr<Socket> socket) const
{
  std::map<Ptr<Socket>, TxBuffer_t>::const_iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  return it->second.clientTs;
}


EdgeHttpHeader::ContentType_t
EdgeHttpServerTxBuffer::GetBufferContentType (Ptr<Socket> socket) const
{
  std::map<Ptr<Socket>, TxBuffer_t>::const_iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  return it->second.txBufferContentType;
}


uint32_t
EdgeHttpServerTxBuffer::GetBufferSize (Ptr<Socket> socket) const
{
  std::map<Ptr<Socket>, TxBuffer_t>::const_iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  return it->second.txBufferSize;
}


bool
EdgeHttpServerTxBuffer::HasTxedPartOfObject (Ptr<Socket> socket) const
{
  std::map<Ptr<Socket>, TxBuffer_t>::const_iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found");
  return it->second.hasTxedPartOfObject;
}


void
EdgeHttpServerTxBuffer::WriteNewObject (Ptr<Socket> socket,
                                            EdgeHttpHeader::ContentType_t contentType,
                                            uint32_t objectSize)
{
  NS_LOG_FUNCTION (this << socket << contentType << objectSize);

  NS_ASSERT_MSG (contentType != EdgeHttpHeader::NOT_SET,
                 "Unable to write an object without a proper Content-Type.");
  NS_ASSERT_MSG (objectSize > 0,
                 "Unable to write a zero-sized object.");

  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  NS_ASSERT_MSG (it->second.txBufferSize == 0,
                 "Cannot write to Tx buffer of socket " << socket
                                                        << " until the previous content has been completely sent.");
  it->second.txBufferContentType = contentType;
  it->second.txBufferSize = objectSize;
  it->second.hasTxedPartOfObject = false;
}


void
EdgeHttpServerTxBuffer::RecordNextServe (Ptr<Socket>    socket,
                                             const EventId  &eventId,
                                             const Time     &clientTs)
{
  NS_LOG_FUNCTION (this << socket << clientTs.As (Time::S));

  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  it->second.nextServe = eventId;
  it->second.clientTs = clientTs;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
EdgeHttpServerTxBuffer::SetobjectBytesToBeReceived (Ptr<Socket>    socket, uint32_t m_objectBytesToBeReceived)
{
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  it->second.m_objectBytesToBeReceived = m_objectBytesToBeReceived;
}

uint32_t
EdgeHttpServerTxBuffer::GetobjectBytesToBeReceived (Ptr<Socket>    socket)
{
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  return it->second.m_objectBytesToBeReceived;
}

void
EdgeHttpServerTxBuffer::SetconstructedPacket (Ptr<Socket>    socket, Ptr<Packet>  m_constructedPacket)
{
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  it->second.m_constructedPacket = m_constructedPacket;
}

Ptr<Packet>
EdgeHttpServerTxBuffer::GetconstructedPacket (Ptr<Socket>    socket)
{
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  return it->second.m_constructedPacket;
}

void
EdgeHttpServerTxBuffer::SetobjectClientTs (Ptr<Socket>    socket, Time  m_objectClientTs)
{
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  it->second.m_objectClientTs = m_objectClientTs;
}

Time
EdgeHttpServerTxBuffer::GetobjectClientTs (Ptr<Socket>    socket)
{
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  return it->second.m_objectClientTs;
}

void
EdgeHttpServerTxBuffer::SetobjectServerTs (Ptr<Socket>    socket, Time  m_objectServerTs)
{
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  it->second.m_objectServerTs = m_objectServerTs;
}

Time
EdgeHttpServerTxBuffer::GetobjectServerTs (Ptr<Socket>    socket)
{
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  return it->second.m_objectServerTs;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void
EdgeHttpServerTxBuffer::DepleteBufferSize (Ptr<Socket> socket, uint32_t amount)
{
  NS_LOG_FUNCTION (this << socket << amount);

  NS_ASSERT_MSG (amount > 0, "Unable to consume zero bytes.");

  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  NS_ASSERT_MSG (it->second.txBufferSize >= amount,
                 "The requested amount is larger than the current buffer size.");
  it->second.txBufferSize -= amount;
  it->second.hasTxedPartOfObject = true;

  if (it->second.isClosing && (it->second.txBufferSize == 0))
    {
      /*
       * The peer has earlier issued a close request and we have now waited
       * until all the existing data are pushed into the socket. Now we close
       * the socket explicitly.
       */
      CloseSocket (socket);
    }
}


void
EdgeHttpServerTxBuffer::PrepareClose (Ptr<Socket> socket)
{
  NS_LOG_FUNCTION (this << socket);
  std::map<Ptr<Socket>, TxBuffer_t>::iterator it;
  it = m_txBuffer.find (socket);
  NS_ASSERT_MSG (it != m_txBuffer.end (),
                 "Socket " << socket << " cannot be found.");
  it->second.isClosing = true;
}


} // end of `namespace ns3`
