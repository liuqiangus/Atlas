/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2013 Magister Solutions
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Budiarto Herman <budiarto.herman@magister.fi>
 *
 */

#include "edge-http-variables.h"

#include <ns3/log.h>
#include <ns3/uinteger.h>
#include <ns3/double.h>
#include <math.h>


NS_LOG_COMPONENT_DEFINE ("EdgeHttpVariables");

namespace ns3 {


NS_OBJECT_ENSURE_REGISTERED (EdgeHttpVariables);


EdgeHttpVariables::EdgeHttpVariables ()
{
  NS_LOG_FUNCTION (this);
  m_mtuSizeRng = CreateObject<UniformRandomVariable> ();
  // m_requestSizeRng = CreateObject<ConstantRandomVariable> ();
  m_requestSizeRng = CreateObject<NormalRandomVariable> ();

  m_mainObjectGenerationDelayRng = CreateObject<ConstantRandomVariable> ();
  m_mainObjectSizeRng = CreateObject<NormalRandomVariable> ();
  m_computeTimeRng = CreateObject<NormalRandomVariable> ();
  m_parsingTimeRng = CreateObject<ConstantRandomVariable> ();
  // m_parsingTimeRng = CreateObject<ExponentialRandomVariable> ();
}


// static
TypeId
EdgeHttpVariables::GetTypeId ()
{
  static TypeId tid = TypeId ("ns3::EdgeHttpVariables")
    .SetParent<Object> ()
    .AddConstructor<EdgeHttpVariables> ()

    // REQUEST SIZE
    // .AddAttribute ("RequestSize",
    //                "The constant size of HTTP request packet (in bytes).",
    //                UintegerValue (131050),
    //                MakeUintegerAccessor (&EdgeHttpVariables::SetRequestSize),
    //                MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("RequestSizeMean",
                   "The mean of main object sizes (in bytes).",
                   UintegerValue (107100),
                   MakeUintegerAccessor (&EdgeHttpVariables::SetRequestSizeMean),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("RequestSizeStdDev",
                   "The standard deviation of main object sizes (in bytes).",
                   UintegerValue (25032),
                   MakeUintegerAccessor (&EdgeHttpVariables::SetRequestSizeStdDev),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("RequestSizeMin",
                   "The minimum value of main object sizes (in bytes).",
                   UintegerValue (100),
                   MakeUintegerAccessor (&EdgeHttpVariables::m_requestSizeMin),
                   MakeUintegerChecker<uint32_t> (22))
    .AddAttribute ("RequestSizeMax",
                   "The maximum value of main object sizes (in bytes).",
                   UintegerValue (2000000), // 2 MB
                   MakeUintegerAccessor (&EdgeHttpVariables::m_requestSizeMax),
                   MakeUintegerChecker<uint32_t> ())

    // MAIN OBJECT GENERATION DELAY
    .AddAttribute ("MainObjectGenerationDelay",
                   "The constant time needed by HTTP server "
                   "to generate a main object as a response.",
                   TimeValue (MilliSeconds (0)),
                   MakeTimeAccessor (&EdgeHttpVariables::SetMainObjectGenerationDelay),
                   MakeTimeChecker ())

    // MAIN OBJECT SIZE
    .AddAttribute ("MainObjectSizeMean",
                   "The mean of main object sizes (in bytes).",
                   UintegerValue (107100),
                   MakeUintegerAccessor (&EdgeHttpVariables::SetMainObjectSizeMean),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("MainObjectSizeStdDev",
                   "The standard deviation of main object sizes (in bytes).",
                   UintegerValue (25032),
                   MakeUintegerAccessor (&EdgeHttpVariables::SetMainObjectSizeStdDev),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("MainObjectSizeMin",
                   "The minimum value of main object sizes (in bytes).",
                   UintegerValue (100),
                   MakeUintegerAccessor (&EdgeHttpVariables::m_mainObjectSizeMin),
                   MakeUintegerChecker<uint32_t> (22))
    .AddAttribute ("MainObjectSizeMax",
                   "The maximum value of main object sizes (in bytes).",
                   UintegerValue (2000000), // 2 MB
                   MakeUintegerAccessor (&EdgeHttpVariables::m_mainObjectSizeMax),
                   MakeUintegerChecker<uint32_t> ())

    // // READING TIME
    // .AddAttribute ("ComputeTimeMean",
    //                "The mean of reading time.",
    //                TimeValue (MilliSeconds (100)),
    //                MakeTimeAccessor (&EdgeHttpVariables::SetComputeTimeMean),
    //                MakeTimeChecker ())
    .AddAttribute ("ComputeTimeMean",
                   "The mean of compute time (in ms).",
                   UintegerValue (100),
                   MakeUintegerAccessor (&EdgeHttpVariables::SetComputeTimeMean),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("ComputeTimeStdDev",
                   "The standard deviation of compute time (in ms).",
                   UintegerValue (10),
                   MakeUintegerAccessor (&EdgeHttpVariables::SetComputeTimeStdDev),
                   MakeUintegerChecker<uint32_t> ())
    .AddAttribute ("ComputeTimeMin",
                   "The minimum value of compute time (in ms).",
                   UintegerValue (1),
                   MakeUintegerAccessor (&EdgeHttpVariables::m_computeTimeMin),
                   MakeUintegerChecker<uint32_t> (22))
    .AddAttribute ("ComputeTimeMax",
                   "The maximum value of compute time (in ms).",
                   UintegerValue (1000), // 1 sec
                   MakeUintegerAccessor (&EdgeHttpVariables::m_computeTimeMax),
                   MakeUintegerChecker<uint32_t> ())
    // PARSING TIME
    .AddAttribute ("ParsingTimeMean",
                   "The mean of parsing time.",
                   TimeValue (MilliSeconds (130)),
                   MakeTimeAccessor (&EdgeHttpVariables::SetParsingTimeMean),
                   MakeTimeChecker ())

    // MTU SIZE
    .AddAttribute ("LowMtuSize",
                   "The lower MTU size.",
                   UintegerValue (536),
                   MakeUintegerAccessor (&EdgeHttpVariables::m_lowMtu),
                   MakeUintegerChecker<uint32_t> (0))
    .AddAttribute ("HighMtuSize",
                   "The higher MTU size.",
                   UintegerValue (1460),
                   MakeUintegerAccessor (&EdgeHttpVariables::m_highMtu),
                   MakeUintegerChecker<uint32_t> (0))
    .AddAttribute ("HighMtuProbability",
                   "The probability that higher MTU size is used.",
                   DoubleValue (0.76),
                   MakeDoubleAccessor (&EdgeHttpVariables::m_highMtuProbability),
                   MakeDoubleChecker<double> (0, 1))
  ;
  return tid;

}


uint32_t
EdgeHttpVariables::GetMtuSize ()
{
  const double r = m_mtuSizeRng->GetValue ();
  NS_ASSERT (r >= 0.0);
  NS_ASSERT (r < 1.0);
  if (r < m_highMtuProbability)
    {
      return m_highMtu; // 1500 bytes if including TCP header.
    }
  else
    {
      return m_lowMtu; // 576 bytes if including TCP header.
    }
}


// uint32_t
// EdgeHttpVariables::GetRequestSize ()
// {
//   return m_requestSizeRng->GetInteger ();
// }

uint32_t
EdgeHttpVariables::GetRequestSize ()
{
  // Validate parameters.
  if (m_requestSizeMax <= m_requestSizeMin)
    {
      NS_FATAL_ERROR ("`requestSizeMax` attribute "
                      << " must be greater than"
                      << " the `requestSizeMin` attribute.");
    }

  /*
   * Repeatedly draw one new random value until it falls in the interval
   * [min, max). The previous validation ensures this process does not loop
   * indefinitely.
   */
  uint32_t value;
  do
    {
      value = m_requestSizeRng->GetValue ();
    }
  while ((value < m_requestSizeMin) || (value >= m_requestSizeMax));

  return value;
}


Time
EdgeHttpVariables::GetMainObjectGenerationDelay ()
{
  return Seconds (m_mainObjectGenerationDelayRng->GetValue ());
}


uint32_t
EdgeHttpVariables::GetMainObjectSize ()
{
  // Validate parameters.
  if (m_mainObjectSizeMax <= m_mainObjectSizeMin)
    {
      NS_FATAL_ERROR ("`MainObjectSizeMax` attribute "
                      << " must be greater than"
                      << " the `MainObjectSizeMin` attribute.");
    }

  /*
   * Repeatedly draw one new random value until it falls in the interval
   * [min, max). The previous validation ensures this process does not loop
   * indefinitely.
   */
  uint32_t value;
  do
    {
      value = m_mainObjectSizeRng->GetValue ();
    }
  while ((value < m_mainObjectSizeMin) || (value >= m_mainObjectSizeMax));

  return value;
}




Time
EdgeHttpVariables::GetComputeTime ()
{
  return MilliSeconds (std::max(m_computeTimeRng->GetValue (), 0.0)); // todo change the value to millsecond when it is set
}


Time
EdgeHttpVariables::GetParsingTime ()
{
  return Seconds (std::max(m_parsingTimeRng->GetValue (), 0.0));
}


int64_t
EdgeHttpVariables::AssignStreams (int64_t stream)
{
  NS_LOG_FUNCTION (this << stream);

  m_mtuSizeRng->SetStream (stream);
  m_requestSizeRng->SetStream (stream + 1);
  m_mainObjectGenerationDelayRng->SetStream (stream + 2);
  m_mainObjectSizeRng->SetStream (stream + 3);
  // m_embeddedObjectGenerationDelayRng->SetStream (stream + 4);
  // m_embeddedObjectSizeRng->SetStream (stream + 5);
  // m_numOfEmbeddedObjectsRng->SetStream (stream + 6);
  m_computeTimeRng->SetStream (stream + 7);
  m_parsingTimeRng->SetStream (stream + 8);

  return 9;
}

void
EdgeHttpVariables::DoInitialize (void)
{
  NS_LOG_FUNCTION (this);
  UpdateMainObjectMuAndSigma ();
  UpdateRequestMuAndSigma();
  UpdateComputeTimeMuAndSigma();
}

// SETTER METHODS /////////////////////////////////////////////////////////////


// void
// EdgeHttpVariables::SetRequestSize (uint32_t constant)
// {
//   NS_LOG_FUNCTION (this << constant);
//   m_requestSizeRng->SetAttribute ("Constant",
//                                   DoubleValue (static_cast<double> (constant)));
// }

void
EdgeHttpVariables::UpdateRequestMuAndSigma (void)
{
  NS_LOG_FUNCTION (this);
  // const double a1 = std::pow (m_requestSizeStdDev, 2.0);
  // const double a2 = std::pow (m_requestSizeMean, 2.0);
  // const double a = std::log (1.0 + (a1 / a2));
  // const double mu = std::log (m_requestSizeMean) - (0.5 * a);
  // const double sigma = std::sqrt (a);
  const double mu = m_requestSizeMean;
  const double sigma = m_requestSizeStdDev;
  NS_LOG_DEBUG (this << " Mu= " << mu << " Sigma= " << sigma << ".");
  m_requestSizeRng->SetAttribute ("Mean", DoubleValue (mu));
  m_requestSizeRng->SetAttribute ("Variance", DoubleValue (sigma*sigma));
}

void
EdgeHttpVariables::SetRequestSizeMean (uint32_t mean)
{
  NS_LOG_FUNCTION (this << mean);
  NS_ASSERT_MSG (mean > 0, "Mean must be greater than zero.");
  m_requestSizeMean = mean;

  if (IsInitialized ())
    {
      UpdateRequestMuAndSigma ();
    }
}


void
EdgeHttpVariables::SetRequestSizeStdDev (uint32_t stdDev)
{
  NS_LOG_FUNCTION (this << stdDev);
  m_requestSizeStdDev = stdDev;
  
  if (IsInitialized ())
    {
      UpdateRequestMuAndSigma ();
    }
}

void
EdgeHttpVariables::SetMainObjectGenerationDelay (Time constant)
{
  NS_LOG_FUNCTION (this << constant.As (Time::S));
  m_mainObjectGenerationDelayRng->SetAttribute ("Constant",
                                                DoubleValue (constant.GetSeconds ()));
}

void
EdgeHttpVariables::UpdateMainObjectMuAndSigma (void)
{
  NS_LOG_FUNCTION (this);
  // const double a1 = std::pow (m_mainObjectSizeStdDev, 2.0);
  // const double a2 = std::pow (m_mainObjectSizeMean, 2.0);
  // const double a = std::log (1.0 + (a1 / a2));
  // const double mu = std::log (m_mainObjectSizeMean) - (0.5 * a);
  // const double sigma = std::sqrt (a);
  const double mu = m_mainObjectSizeMean;
  const double sigma = m_mainObjectSizeStdDev;
  NS_LOG_DEBUG (this << " Mu= " << mu << " Sigma= " << sigma << ".");
  // m_mainObjectSizeRng->SetAttribute ("Mu", DoubleValue (mu));
  // m_mainObjectSizeRng->SetAttribute ("Sigma", DoubleValue (sigma));
  m_mainObjectSizeRng->SetAttribute ("Mean", DoubleValue (mu));
  m_mainObjectSizeRng->SetAttribute ("Variance", DoubleValue (sigma*sigma));
}

void
EdgeHttpVariables::SetMainObjectSizeMean (uint32_t mean)
{
  NS_LOG_FUNCTION (this << mean);
  NS_ASSERT_MSG (mean > 0, "Mean must be greater than zero.");
  m_mainObjectSizeMean = mean;

  if (IsInitialized ())
    {
      UpdateMainObjectMuAndSigma ();
    }
}


void
EdgeHttpVariables::SetMainObjectSizeStdDev (uint32_t stdDev)
{
  NS_LOG_FUNCTION (this << stdDev);
  m_mainObjectSizeStdDev = stdDev;
  
  if (IsInitialized ())
    {
      UpdateMainObjectMuAndSigma ();
    }
}

// void
// EdgeHttpVariables::SetComputeTimeMean (Time mean)
// {
//   NS_LOG_FUNCTION (this << mean.As (Time::S));
//   m_computeTimeRng->SetAttribute ("Mean", DoubleValue (mean.GetSeconds ()));
// }


void
EdgeHttpVariables::UpdateComputeTimeMuAndSigma (void)
{
  NS_LOG_FUNCTION (this);
  // const double a1 = std::pow (m_requestSizeStdDev, 2.0);
  // const double a2 = std::pow (m_requestSizeMean, 2.0);
  // const double a = std::log (1.0 + (a1 / a2));
  // const double mu = std::log (m_requestSizeMean) - (0.5 * a);
  // const double sigma = std::sqrt (a);
  const double mu = m_computeTimeMean;
  const double sigma = m_computeTimeStdDev;
  NS_LOG_DEBUG (this << " Mu= " << mu << " Sigma= " << sigma << ".");
  m_computeTimeRng->SetAttribute ("Mean", DoubleValue (mu));
  m_computeTimeRng->SetAttribute ("Variance", DoubleValue (sigma*sigma));
}

void
EdgeHttpVariables::SetComputeTimeMean (uint32_t mean)
{
  NS_LOG_FUNCTION (this << mean);
  NS_ASSERT_MSG (mean > 0, "Mean must be greater than zero.");
  m_computeTimeMean = mean;

  if (IsInitialized ())
    {
      UpdateComputeTimeMuAndSigma ();
    }
}


void
EdgeHttpVariables::SetComputeTimeStdDev (uint32_t stdDev)
{
  NS_LOG_FUNCTION (this << stdDev);
  m_computeTimeStdDev = stdDev;
  
  if (IsInitialized ())
    {
      UpdateComputeTimeMuAndSigma ();
    }
}


void
EdgeHttpVariables::SetParsingTimeMean (Time constant)
{
  // NS_LOG_FUNCTION (this << mean.As (Time::S));
  // m_parsingTimeRng->SetAttribute ("Mean", DoubleValue (mean.GetSeconds ()));
  NS_LOG_FUNCTION (this << constant.As (Time::S));
  m_parsingTimeRng->SetAttribute ("Constant",DoubleValue (constant.GetSeconds ()));
}


} // end of `namespace ns3`
